<?php

namespace App;

use Illuminate\Notifications\Notifiable;


class UserMeta extends Model {

    use Notifiable;

}
