<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use App\User;
use Carbon\Carbon;
use App\VerificationCodes;
use DB;
use App\Tokens;
use GuzzleHttp\Client;
use Meng\AsyncSoap\Guzzle\Factory;
use Validator;
use App\Notifications;

class NotificationsController extends Controller {

    //######################### GET ALL NOTIFICATIONS #########################
    public function index(User $CURRENT_USER) {
        $notifications = Notifications::where("user_id", $CURRENT_USER->user_id)->get();
        return response()->json(compact('notifications'));
    }
}
