<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\User;
use GuzzleHttp\Client;
use Validator;
use App\Transactions;
use App\TransactionLog;
use Flutterwave\Card;
use Flutterwave\Flutterwave;
use Flutterwave\Currencies;
use DB;
use App\Services\HollaPayService;

class TransactionsController extends Controller {

    var $BASE_URI_MONEYWAVE = "https://moneywave.herokuapp.com";

    public function index(Request $request, User $CURRENT_USER) {
        $limit = $request->input("limit");

        if ($limit > 0) {
            $transactions = Transactions::with('beneficiary')
                    ->with('sender')
                    ->where("user_id", $CURRENT_USER->user_id)
                    ->orderBy('created_at', 'desc')
                    ->limit($limit)
                    ->get();
        } else {
            $transactions = Transactions::with('beneficiary')
                    ->with('sender')
                    ->where("user_id", $CURRENT_USER->user_id)
                    ->orderBy('created_at', 'desc')
                    ->get();
        }
        return response()->json(compact('transactions'));
    }

    public function send(Request $request, User $CURRENT_USER, HollaPayService $hollapay) {
        //========= GET POST VARIABLES =========
        $amount = $request->input('amount');
        $source = $request->input('source');
        $card_token = $request->input('card_token');
        $beneficiary = $request->input('beneficiary');

        //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\
        $code = "";

        //========= STORE TRANSACTION ==============
        $transaction = new Transactions();
        $transaction->user_id = $CURRENT_USER->user_id;
        $transaction->_from = "Card";
        $transaction->_to = $beneficiary;
        $transaction->text = "You transferred ₦" . $amount . " to " . $beneficiary;
        $transaction->transaction_type = "Debit";
        $transaction->amount = $amount;
        $transaction->save();

        //========= STORE TRANSACTION LOG ==============
        $tLog = new TransactionLog();
        $tLog->user_id = $CURRENT_USER->user_id;
        $tLog->transaction_id = $transaction->id;
        $tLog->transaction_type = "Preauthorization";
        $tLog->amount = $amount;
        $tLog->status = "pending";
        $tLog->save();


        if ($source == "Account Balance") {//use HollaPay Balance
            if ($CURRENT_USER->balance >= $amount) {//Check user's balance
                $user = User::find($CURRENT_USER->id);
                $balance = $user->balance;
                $newBalance = $balance - $amount; //Debit the user's account
                $user->balance = $newBalance;
                $user->save();

                //Beneficiary 
                $user2 = User::where("user_id", $beneficiary)->first();
                if (count($user2) > 0) {//User exist
                    $beneficiaryObject = User::find($user2->id);
                    $beneficiaryObject->balance = $beneficiaryObject->balance + $amount;
                    $beneficiaryObject->save();

                    $message = $CURRENT_USER->name . " (" . $CURRENT_USER->user_id . ") just sent you (" . $amount . " Naira). Withdraw at ATM using code " . $code . " or download HollaPay app to transfer to bank or someone else. Go to http://hpay.ng/ for more info";
                    $hollapay->sendSMS($beneficiary, $message);
                } else {//User does not Exist
                    $newUser = new User();
                    $newUser->user_id = $beneficiary;
                    $newUser->balance = $amount;
                    $newUser->save();

                    //\\//\\//\\//\\//\\//\\//\\//\\
                    //Send SMS to Beneficiary
                    $message = $CURRENT_USER->name . " (" . $CURRENT_USER->user_id . ") just sent you (" . $amount . " Naira). Withdraw at ATM using code " . $code . " or download HollaPay app to transfer to bank or someone else. Go to http://hpay.ng/ for more info";
                    $hollapay->sendSMS($beneficiary, $message);
                }
                $success = "Funds has been successfully transferred";
                return response()->json(compact('success'));
            } else {
                $error = "Insufficient Funds";
                return response()->json(compact('error'));
            }
        }

        //============ Use Existing Card Token ============
        else if ($source == "Existing Card") {
            $card_token = $request->input('card_token');
            $result = $hollapay->preAuth($card_token, $amount);

            if ($result->isSuccessfulResponse()) {

                $response = $result->getResponseData();
                $authorizeId = $response["data"]["authorizeId"];
                $transactionreference = $response["data"]["transactionreference"];

                //=========== LOG IT ===========
                $tLog->reference = $transactionreference;
                $tLog->status = "successful";
                $tLog->save();

                $tLog = new TransactionLog();
                $tLog->user_id = $CURRENT_USER->user_id;
                $tLog->transaction_id = $transaction->id;
                $tLog->transaction_type = "Capture";
                $tLog->amount = $amount;
                $tLog->status = "pending";
                $tLog->save();



                $result = $hollapay->capture($transactionreference, $authorizeId, $amount);
                if ($result->isSuccessfulResponse()) {//Charged card Successffully
                    $tLog->status = "successful";
                    $tLog->save();

                    //=== Get the User and Compute new Balance ===
                    $user = User::find($CURRENT_USER->id);
                    $balance = $user->balance;
                    $balance = $balance - $amount;
                    $user->balance = $balance;
                    $user->save();

                    //Beneficiary 
                    $user2 = User::where("user_id", $beneficiary)->first();
                    if (count($user2) > 0) {//User exist
                        $beneficiaryObject = User::find($user2->id);
                        $beneficiaryObject->balance = $beneficiaryObject->balance + $amount;
                        $beneficiaryObject->save();

                        $message = $CURRENT_USER->name . " (" . $CURRENT_USER->user_id . ") just sent you (" . $amount . " Naira). Withdraw at ATM using code " . $code . " or download HollaPay app to transfer to bank or someone else. Go to http://hpay.ng/ for more info";
                        $hollapay->sendSMS($beneficiary, $message);
                    } else {//User does not Exist
                        $newUser = new User();
                        $newUser->user_id = $beneficiary;
                        $newUser->balance = $amount;
                        $newUser->save();

                        //\\//\\//\\//\\//\\//\\//\\//\\
                        //Send SMS to Beneficiary
                        $message = $CURRENT_USER->name . " (" . $CURRENT_USER->user_id . ") just sent you (" . $amount . " Naira). Withdraw at ATM using code " . $code . " or download HollaPay app to transfer to bank or someone else. Go to http://hpay.ng/ for more info";
                        $hollapay->sendSMS($beneficiary, $message);
                    }
                    $success = "Funds has been successfully transferred.";
                    return response()->json(compact('success'));
                } else {
                    $tLog->status = "failed";
                    $tLog->save();
                    $error = "Could not Charge the Card";
                    return response()->json(compact('error'));
                }
            } else {
                $tLog->status = "failed";
                $tLog->save();
                //print_r($result);
                $error = "Could not Preauthorize your card: " . $result["data"]["responsemessage"];
                return response()->json(compact('error'));
            }
        }

        //============ Use New Card ============
        else if ($source == "New Card") {
            $card = [
                "card_no" => $request->input("card_number"),
                "cvv" => $request->input("cvv"),
                "expiry_month" => $request->input("expiry_month"),
                "expiry_year" => $request->input("expiry_year")
            ];

            $card_token = $hollapay->tokenize_card($card);

            if (is_array($card_token)) {//An error occured
                $error = $card_token["data"]["responsemessage"];
                return response()->json(compact('error'));
            }
            $result = $hollapay->preAuth($card_token, $amount);

            if ($result->isSuccessfulResponse()) {
                $response = $result->getResponseData();
                $authorizeId = $response["data"]["authorizeId"];
                $transactionreference = $response["data"]["transactionreference"];

                //=========== LOG IT ===========
                $tLog->reference = $transactionreference;
                $tLog->status = "successful";
                $tLog->save();

                $tLog = new TransactionLog();
                $tLog->user_id = $CURRENT_USER->user_id;
                $tLog->transaction_id = $transaction->id;
                $tLog->transaction_type = "Capture";
                $tLog->amount = $amount;
                $tLog->status = "pending";
                $tLog->save();



                $result = $hollapay->capture($transactionreference, $authorizeId, $amount);
                if ($result->isSuccessfulResponse()) {//Charged card Successffully
                    $tLog->status = "successful";
                    $tLog->save();

                    //=== Get the User and Compute new Balance ===
                    $user = User::find($CURRENT_USER->id);
                    $balance = $user->balance;
                    $balance = $balance - $amount;
                    $user->balance = $balance;
                    $user->save();

                    //Beneficiary 
                    $user2 = User::where("user_id", $beneficiary)->first();
                    if (count($user2) > 0) {//User exist
                        $beneficiaryObject = User::find($user2->id);
                        $beneficiaryObject->balance = $beneficiaryObject->balance + $amount;
                        $beneficiaryObject->save();

                        $message = $CURRENT_USER->name . " (" . $CURRENT_USER->user_id . ") just sent you (" . $amount . " Naira). Withdraw at ATM using code " . $code . " or download HollaPay app to transfer to bank or someone else. Go to http://hpay.ng/ for more info";
                        $hollapay->sendSMS($beneficiary, $message);
                    } else {//User does not Exist
                        $newUser = new User();
                        $newUser->user_id = $beneficiary;
                        $newUser->balance = $amount;
                        $newUser->save();

                        //\\//\\//\\//\\//\\//\\//\\//\\
                        //Send SMS to Beneficiary
                        $message = $CURRENT_USER->name . " (" . $CURRENT_USER->user_id . ") just sent you (" . $amount . " Naira). Withdraw at ATM using code " . $code . " or download HollaPay app to transfer to bank or someone else. Go to http://hpay.ng/ for more info";
                        $hollapay->sendSMS($beneficiary, $message);
                    }
                    $success = "Funds has been successfully transferred.";
                    return response()->json(compact('success'));
                } else {
                    $tLog->status = "failed";
                    $tLog->save();
                    $error = "Could not Charge the Card";
                    return response()->json(compact('error'));
                }
            } else {
                $tLog->status = "failed";
                $tLog->save();
                print_r($result);
                $error = "Could not Preauthorize your card: " . $result["data"]["responsemessage"];
                return response()->json(compact('error'));
            }
        }
    }

    //######################### WITHDRAW TO BANK ACCOUNT #########################
    public function withraw_bank(Request $request, User $CURRENT_USER) {
        //========= VALIDATE REQUEST =========
        $validate = Validator::make($request->all(), [
                    'amount' => 'required|min:3|max:6',
                    'acc_number' => 'required|min:10|max:10',
                    'bank_code' => 'required|min:3|max:5',
        ]);
        if ($validate->fails()) {
            $errors = $validate->errors();
            return $errors;
        }

        //========= GET POST VARIABLES =========
        $amount = $request->input('amount');
        $acc_number = $request->input('acc_number');
        $bank = $request->input('bank_code');

        //========= CHECK IF USER HAS ENOUGH MONEY =========
        if ($CURRENT_USER->balance >= $amount) {
            //========= SEND REQUEST =========
            $token = $this->getAccessToken();
            try {
                $client = new Client(['base_uri' => $this->BASE_URI_MONEYWAVE]);
                $response = $client->request('POST', '/v1/disburse', [
                    'headers' => [
                        'Authorization' => $token],
                    'json' => [
                        'lock' => 'Password@123',
                        'amount' => $amount,
                        'bankcode' => $bank,
                        'accountNumber' => $acc_number,
                        'senderName' => "HollaPay",
                        'currency' => "NGN"],
                    'http_errors' => false
                ]);
                $response = $response->getBody()->getContents();
                $response = json_decode($response, true);

                if ($response["status"] == "error") {
                    $error = $response["data"] . "";
                    return response()->json(compact('error'));
                } else {
                    $message = $response["data"]["data"];
                    $message = $message["responsemessage"];
                    $ref = $message["uniquereference"];

                    //========= STORE TRANSACTION ==============
                    $transaction = new Transactions();
                    $transaction->user_id = $user->user_id;
                    $transaction->_from = $user->user_id;
                    $transaction->_to = Auth::user()->user_id;
                    $transaction->text = "You withdrew " . $amount . " naira to your bank acccount";
                    $transaction->transaction_type = "Debit";
                    $transaction->save();

                    //========= DEBIT THE USER'S BALANCE ON HOLLAPAY =========
                    $this_user = User::find($user->user_id);
                    $balance = $this_user->balance;
                    $balance = $balance - $amount;
                    $this_user->balance = $balance;
                    $this_user->save();

                    //========= SEND RRESPONSE TO USER =========
                    $status = "success";
                    $message = "Transaction Successful";
                    $reference = $ref;
                    return response()->json(compact('status', 'message', 'reference'));
                }
            } catch (\ServerException $ex) {
                print_r($ex);
            }
        } else {
            $status = "error";
            $message = "Insufficient funds";
            return response()->json(compact('status', 'message'));
        }
    }

    //######################### WITHDRAW TO ATM #########################
    public function withraw_atm(Request $request, User $CURRENT_USER) {
        //========= VALIDATE REQUEST =========
        $validate = Validator::make($request->all(), [
                    'amount' => 'required|min:3|max:6',
        ]);
        if ($validate->fails()) {
            $errors = $validate->errors();
            return $errors;
        }

        //========= GET POST VARIABLES =========
        $amount = $request->input('amount');

        //========= CHECK IF USER HAS ENOUGH MONEY =========
        if ($CURRENT_USER->balance >= $amount) {

            //========= TRANSFER FROM HOLLAPAY TO USER =========
            //========= STORE TRANSACTION ==============
            $transaction = new Transactions();
            $transaction->user_id = $user->user_id;
            $transaction->_from = $user->user_id;
            $transaction->_to = Auth::user()->user_id;
            $transaction->text = "You withdrew " . $amount . " naira";
            $transaction->transaction_type = "Debit";
            $transaction->save();

            //========= DEBIT THE USER'S BALANCE ON HOLLAPAY =========
            $this_user = User::find($user->user_id);
            $balance = $this_user->balance;
            $balance = $balance - $amount;
            $this_user->balance = $balance;
            $this_user->save();

            //========= SEND RRESPONSE TO USER =========
            $status = "success";
            $message = "Transaction Successful";
            $reference = $ref;
            return response()->json(compact('status', 'message', 'reference'));
        } else {
            $error = "Insufficient funds";
            return response()->json(compact('error'));
        }
    }

    //######################### GENERATE FACTS #########################
    public function generateFacts(User $CURRENT_USER) {
        $currentFactType = $this->generateFactType($CURRENT_USER);
        $currentFactType = "spendPercent";

        if ($currentFactType == "highestSent") {
            $transactions = Transactions::select('_to', DB::raw('count(*) as frequency'))
                    ->groupBy('_to')
                    ->orderBy('_to', 'desc')
                    ->where('_from', $CURRENT_USER->user_id)
                    ->limit(1)
                    ->first();
            $fact = "You have sent more money to " . $transactions->_to;
            return response()->json(compact('fact'));
        } else if ($currentFactType == "highestReceived") {
            $transactions = Transactions::select('_from', DB::raw('count(*) as frequency'))
                    ->groupBy('_from')
                    ->orderBy('_from', 'desc')
                    ->where('_to', $CURRENT_USER->user_id)
                    ->limit(1)
                    ->first();
            $fact = "You have received more money from " . $transactions->_from;
            return response()->json(compact('fact'));
        } else if ($currentFactType == "spendPercent") {
            $received = Transactions::where('user_id', $CURRENT_USER->user_id)
                    ->where('transaction_type', 'Credit')
                    ->sum('amount');

            $spent = Transactions::where('user_id', $CURRENT_USER->user_id)
                    ->where('transaction_type', 'Debit')
                    ->sum('amount');
            $perc = ($spent * 100) / $received;
            $fact = "You have spent " . $perc . "% (₦" . $spent . ".00) of your received money";
            return response()->json(compact('fact'));
        }

        $fact = "You have not performed any transaction";
        return response()->json(compact('fact'));
    }

    private function generateFactType($user) {
        $fact_type = array(
            "highestSent",
            "highestReceived",
            "spendPercent",
            "spendPercentMonth",
            "spendPercentAllTime",
            "unusualSpending");
        $currentFactType = $fact_type[array_rand($fact_type)];

        return $currentFactType;
    }

    function getAccessToken() {
        //Get Access Key
        $client = new Client(['base_uri' => $this->BASE_URI_MONEYWAVE]);
        $response = $client->request('POST', '/v1/merchant/verify', [
            'json' => [
                'apiKey' => 'ts_XMRPIE38TACPUGJP81GW',
                'secret' => 'ts_6BS4TFX6YOC5S358TN8Y6AJ8OJ74VS']
        ]);
        $response = $response->getBody()->getContents();
        $token = json_decode($response, true);
        return $token["token"];
    }

    function getAccountName(Request $request) {
        $acc_num = $request->input("acc_number");
        $bank_code = $request->input("bank_code");
        //Get Access Key
        $apiKey = "tk_TM4fIPpCrmy9gJcYq280";
        $merchantKey = "tk_8hBUK9Vx4u";
        $client = new Client(['base_uri' => "http://staging1flutterwave.co:8080"]);
        $response = $client->request('POST', '/pwc/rest/pay/resolveaccount', [
            'json' => [
                'destbankcode' => $this->encrypt3Des($bank_code, $apiKey),
                'recipientaccount' => $this->encrypt3Des($acc_num, $apiKey),
                'merchantid' => $merchantKey]
        ]);
        $response = $response->getBody()->getContents();
        $response = json_decode($response, true);
        $data = $response["data"];
        return response()->json(compact('data'));
    }

    public function encrypt3Des($data, $key) {
        //Generate a key from a hash
        $key = md5(utf8_encode($key), true);

        //Take first 8 bytes of $key and append them to the end of $key.
        $key .= substr($key, 0, 8);

        //Pad for PKCS7
        $blockSize = mcrypt_get_block_size('tripledes', 'ecb');
        $len = strlen($data);
        $pad = $blockSize - ($len % $blockSize);
        $data = $data . str_repeat(chr($pad), $pad);

        //Encrypt data
        $encData = mcrypt_encrypt('tripledes', $key, $data, 'ecb');

        //return $this->strToHex($encData);

        return base64_encode($encData);
    }

    private function preAuth($token, $amount) {
        $currency = Currencies::NAIRA;
        $merchantKey = "tk_8hBUK9Vx4u";
        $apiKey = "tk_TM4fIPpCrmy9gJcYq280";
        $env = "staging";

        Flutterwave::setMerchantCredentials($merchantKey, $apiKey, $env);
        $result = Card::preAuthorize($token, $amount, $currency);
        return $result;
    }

    private function capture($authRef, $transId, $amount) {
        $merchantKey = "tk_8hBUK9Vx4u";
        $apiKey = "tk_TM4fIPpCrmy9gJcYq280";
        $env = "staging";

        Flutterwave::setMerchantCredentials($merchantKey, $apiKey, $env);
        $currency = Currencies::NAIRA;
        $result = Card::capture($authRef, $transId, $amount, $currency);
        return $result;
    }

}
