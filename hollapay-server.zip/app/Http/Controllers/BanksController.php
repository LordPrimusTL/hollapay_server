<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Banks;
use App\User;
use Carbon\Carbon;
use App\VerificationCodes;
use DB;
use App\Tokens;
use GuzzleHttp\Client;
use Meng\AsyncSoap\Guzzle\Factory;
use Validator;

class BanksController extends Controller {

    public function get(User $CURRENT_USER) {
        $banks = Banks::where('user_id', $CURRENT_USER->user_id)->get();

        if (count($banks) > 0) {
            return response()->json(compact('banks'));
        } else {
            $error = "You have not added any Bank Account yet";
            return response()->json(compact('error'));
        }
    }

    //################### ADD BANK ###################
    public function add(Request $request, User $CURRENT_USER) {
        //dd($request);
        //========== Save to Database ==========
        $bank = new Banks();
        $bank->user_id = $CURRENT_USER->user_id;
        $bank->bank_name = $request->input("bank_name");
        $bank->bank_code = $request->input("bank_code");
        $bank->acc_number = $request->input("acc_number");
        $bank->acc_name = $request->input("acc_name");
        $bank->save();

        $success = "Bank Account added successfully";
        return response()->json(compact('success'));
    }

    //################### EDIT BANK ###################
    public function edit(Request $request, User $CURRENT_USER) {
        $bank = Banks::find($request->id);
        $bank->user_id = $CURRENT_USER->user_id;
        $bank->bank_name = $request->input("bank_name");
        $bank->bank_code = $request->input("bank_code");
        $bank->acc_number = $request->input("acc_number");
        $bank->acc_name = $request->input("acc_name");
        $bank->save();
        
        $success = "The bank account has been edited successfully";
        return response()->json(compact('success'));
    }

    //################### DELETE BANK ###################
    public function delete(Request $request, User $CURRENT_USER) {
        $id = $request->input("id");
        Banks::where("id", $id)->delete();

        $success = "Bank successfully deleted";
        return response()->json(compact('success'));
    }

}
