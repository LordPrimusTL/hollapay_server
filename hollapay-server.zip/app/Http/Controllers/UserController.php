<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use App\User;
use Carbon\Carbon;
use App\VerificationCodes;
use DB;
use App\Tokens;
use GuzzleHttp\Client;

class UserController extends Controller {

    var $server = "http://hollapay.fincoapps.com";
    public function index() {
        // TODO: show users
    }

    public function edit(Request $request, User $CURRENT_USER) {

        $user = User::find($CURRENT_USER->id);

        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $user->gender = $request->input('gender');
        $user->save();
        $user->token = $request->input('token');

        //$user = User::where("user_id", $CURRENT_USER->user_id)->first();
        return response()->json(compact('user'));
    }

    public function uploadImage(Request $request, User $CURRENT_USER) {
        $destinationPath = public_path() . '/uploads/images';
        $filename = $CURRENT_USER->user_id . "_" . $request->file('file')->getClientOriginalName();
        $upload_success = $request->file('file')->move($destinationPath, $filename);
        
        
        //================ UPDATE USER DETAILS IN DB //================
        $user = User::find($CURRENT_USER->id);

        $user->image = "http://hollapay.fincoapps.com/public/uploads/images/".$filename;
        $user->save();
        $user->token = $request->input('token');

        return response()->json(compact('user'));
    }

}
